using AutoMapper;

namespace DatingApp.API.Helpers
{
    public class AutoMapperProfiles: Profile
    {
        
    }
}