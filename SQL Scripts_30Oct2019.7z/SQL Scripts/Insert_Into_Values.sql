USE [DatingApp.db]
GO

INSERT INTO [dbo].[Values]
           ([Name])
     VALUES
           ('Value 101')
GO
INSERT INTO [dbo].[Values]
           ([Name])
     VALUES
           ('Value 102')
GO
INSERT INTO [dbo].[Values]
           ([Name])
     VALUES
           ('Value 103')
GO
INSERT INTO [dbo].[Values]
           ([Name])
     VALUES
           ('Value 104')
GO


